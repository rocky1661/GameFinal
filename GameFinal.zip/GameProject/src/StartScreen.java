import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import java.awt.Panel;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;

public class StartScreen extends JFrame {

	private JPanel contentPane;
	private JButton Btn;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StartScreen frame = new StartScreen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StartScreen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Btn = new JButton("TicTacToe");
		Btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String callingBtn = e.getActionCommand();
				if (callingBtn == "TicTacToe") {
				
					TicTacToe.main(null);
				}
			
			}
		});
		Btn.setBounds(44, 179, 143, 44);
		contentPane.add(Btn);
		
		btnNewButton = new JButton("Rock Paper Scissors");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String callingBtn = e.getActionCommand();
				if (callingBtn == "Rock Paper Scissors") {
				
					RockPaperScissors.main(null);
			
			
				}
			}
			
		});
		btnNewButton.setBounds(217, 179, 160, 44);
		contentPane.add(btnNewButton);
		
		JLabel lblChooseToPlay = new JLabel("Choose to play game");
		lblChooseToPlay.setFont(new Font("Vivaldi", Font.BOLD | Font.ITALIC, 35));
		lblChooseToPlay.setBackground(new Color(0, 204, 102));
		lblChooseToPlay.setBounds(105, 54, 258, 101);
		contentPane.add(lblChooseToPlay);
	}
}